2. dia
# Ez egy egysoros megjegyzés
print("Hello, világ!")  # Ez is egy megjegyzés



# Ez egy többsoros megjegyzés
# amely több soron keresztül
# folytatódik.
print("Hello, világ!")



"""
Ez egy többsoros
karakterlánc, amely
kommentként is használható.
"""
print("Hello, világ!")


3. dia
# Egész szám típusú változó
szam = 10
print(szam)  # Kimenet: 10

# Lebegőpontos szám típusú változó
pi = 3.14
print(pi)  # Kimenet: 3.14

# Sztring típusú változó
szoveg = "Hello, világ!"
print(szoveg)  # Kimenet: Hello, világ!

# Logikai típusú változó
igaz_hamis = True
print(igaz_hamis)  # Kimenet: True

4.dia

x = 5         # x most egy egész szám
print(x)      # Kimenet: 5

x = "Hello"   # x most egy sztring
print(x)      # Kimenet: Hello

x = 3.14      # x most egy lebegőpontos szám
print(x)      # Kimenet: 3.14


5.dia
szoveg1 = "Hello, világ!"  # dupla idézőjelek használata
szoveg2 = 'Hello, Python!'  # egyszeres idézőjelek használata
print(szoveg1)  # Kimenet: Hello, világ!
print(szoveg2)  # Kimenet: Hello, Python!



egesz_szam = 42
print(egesz_szam)  # Kimenet: 42



igaz = True
hamis = False
print(igaz)  # Kimenet: True
print(hamis)  # Kimenet: False



6. Dia
x = 10
if x > 5:
    print("x nagyobb, mint 5")



x = 10
if x > 15:
    print("x nagyobb, mint 15")
elif x > 5:
    print("x nagyobb, mint 5, de kisebb vagy egyenlő, mint 15")



x = 3
if x > 15:
    print("x nagyobb, mint 15")
elif x > 5:
    print("x nagyobb, mint 5, de kisebb vagy egyenlő, mint 15")
else:
    print("x kisebb vagy egyenlő, mint 5")


7.dia

szam = 0
while szam < 5:
    print(szam)
    szam += 1



while True:
    print("Ez egy végtelen ciklus. Nyomj meg egy Ctrl+C-t a leállításhoz.")
    
8.dia

nevek = ["Bence", "Attila", "Laci"]
for nev in nevek:
    print(nev)

for i in range(5):
    print(i)
